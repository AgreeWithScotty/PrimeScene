# Smooth Prime for Prime Video

Standalone Kodi application with permanent ID `plugin.video.primeinterface`.
Current release: 0.2.7. Install updates through the ScottyWins repository; do not
uninstall between versions. Account data belongs only to this add-on.

The Aurora Cinema window opens directly from Video add-ons: a matte charcoal
and cool slate hero, horizontal title cards, and a focus state you can read
from the couch. No separate Kodi skin is required. Home, Movies and TV load
real Prime Video titles from the signed-in storefront reader. The focused
title is drawn as large condensed type, with its metadata and full synopsis
under it, including when the rail card did not arrive with those details.
Choosing a card plays it. A movie or episode resolves its playable id and
starts. A series plays the next, in-progress, or earliest episode when one
can be resolved, and opens the episode list only when it cannot. Results append
as each server page arrives.
When Amazon provides a page continuation, the next page starts as you reach
the newest cards.

Website sign-in uses native Kodi prompts for credentials, verification methods,
email/SMS codes, approval and security images. It preserves complete cookie
scope and browser headers. Device registration is separate from website login.
The account button displays the saved name and offers Sign out or Sign in again.
Older accounts without a full website session can reconnect there. Signing out
clears account sessions, lists, history, profiles and artwork.

Settings > Diagnostics > View diagnostic report opens one combined report.
It records installed release, operation IDs, stages, timings, redacted
redirects, HTTP statuses, parser structure and explicit outcomes. Passwords,
verification codes, tokens, cookie values and private account identifiers are
excluded. Current-attempt sign-in diagnostics survive successful account
replacement; prior-account files are erased.

The player overlay is the only control scheme during Smooth Prime playback.
It stays up for the whole title: pause, OK, info and seek bring it back after
it hides, and Back hides it once before a second Back stops playback. Subtitles
and audio are offered when the stream has them. Other videos keep Kodi's own OSD.

The release ZIP contains complete runnable source and the GPL license. No
separately installed Amazon add-on is required. See NOTICE.md for inherited
backend credits and the SmoothFlix Aurora Cinema attribution. Not affiliated
with Amazon.


Navigation in 0.2.5

Home, Movies and TV load in the background. Visited views keep their cards and selection. First pages are saved only inside the active account profile, fresh for 15 minutes and displayable for up to 24 hours while refreshing. Explicit sign-out erases these pages, artwork and title caches. Unknown Amazon continuations remain explicit diagnostic failures. Settings > Diagnostics contains real request, binding, title and image timings. A first uncached provider response still depends on the real service; no simulated provider or Kodi timing tests were used to claim responsiveness.


Descriptions in 0.2.6

Descriptions supplied with catalog pages are merged into the matching title cards. Missing descriptions load ahead for the current card, ten following cards and two previous cards. This uses bounded background metadata work, yields to explicit Play jobs between requests, and never holds the primary page-reader lane. Account-scoped saved descriptions expire after 24 hours and are erased on explicit sign-out. Diagnostics report actual coverage, source, request time and success/unavailable/failure. Provider response availability is not inferred from syntax or package checks. No simulated provider or Kodi tests were run.


TV navigation and artwork in 0.2.8

Movies and individual episodes play their own video. TV shows open an episode browser, with a season selector when Amazon provides multiple linked seasons. The app does not auto-select a resume/first episode for a show card. Selected-title metadata stays separate from child episode metadata. Series pages retain the original catalog position for Back. Cards prefer declared landscape artwork and use a fixed black frame with complete-image fitting for portrait-only fallbacks. No image is stretched to pretend it has another shape. Diagnostics record title actions, returned kinds, season/episode counts and art coverage. No simulated Kodi/provider tests or real-device UI-success claims were made.


Playback return and quiet navigation in 0.2.9

Terminal playback restores the originating selected card after the overlay closes. Return targets are invalidated on exit or account changes; a newer playback cancels an old return command. The UI keeps existing cards while new pages arrive and displays no navigation loading text or title-resolution spinner. Home/Movies/TV navigation stays in the top selectors. Actual-run diagnostics correlate request IDs, terminal reasons, observed window IDs and outcomes.


Playback return and quiet navigation in 0.2.10

Terminal playback restores the originating movie or episode card after the overlay closes. Return targets are invalidated on exit or account changes; a newer playback cancels an old return command. The UI keeps existing cards while new pages arrive and displays no navigation loading text or title-resolution spinner. Home/Movies/TV navigation stays in the top selectors. Actual-run diagnostics correlate request IDs, terminal reasons, observed window IDs and outcomes. Card identity, page, selection, season and Back history are captured at click time. The current view is reused when possible; an in-memory snapshot restores it otherwise.


Four-section catalog in 0.2.12

Movies opens by default. The main selectors are Movies, TV, Sports and Purchases. Movies/TV use the Included with Prime storefront and only retain typed titles with explicit Prime access evidence. A generic entitlement or SVOD label does not establish Prime inclusion. Unknown access is excluded. Sports uses its own storefront. Purchases follows actual account-library links and reads only the library content; Watchlist and recommendations are not substituted. The signed-in library flow has not been observed with a live account. Diagnostics record filter coverage, route discovery and protocol structure. Existing playback, return-to-card behavior, SP artwork and ultramarine styling remain.


TV, focus and account lifecycle in 0.2.14

Top category clicks focus the first real card once, without resetting later appends. TV listings use actual episode relationships and current Amazon detail state when cached season rendering loses episodes. Sign-out revokes the local account generation first, runs all cleanup stages, checks for remaining account files and blocks sign-in if cleanup is incomplete. Sign in again purges the old session first. A website login is saved and announced only after Amazon verifies the session. Amazon determines which verification challenges are required. Diagnostics record actual focus, episode structure, purge stages, residual counts and verification outcomes. Only neutral coordination state and the new cleanup report remain after successful local purge.


TV, focus and account lifecycle in 0.2.15

Top category clicks focus the first real card once, without resetting later appends. TV listings use actual episode relationships and current Amazon detail state when cached season rendering loses episodes. Sign-out revokes the local account generation first, runs all cleanup stages, checks for remaining account files and blocks sign-in if cleanup is incomplete. Sign in again purges the old session first. A website login is saved and announced only after Amazon verifies the session. Amazon determines which verification challenges are required. Diagnostics record actual focus, episode structure, purge stages, residual counts and verification outcomes. Only neutral coordination state and the new cleanup report remain after successful local purge.
