#!/usr/bin/env python
# -*- coding: utf-8 -*-
from sys import argv

from resources.lib.profile_bootstrap import prepare_profile
prepare_profile()
from resources.lib.startup import EntryPoint

if __name__ == '__main__':
    EntryPoint(argv)
