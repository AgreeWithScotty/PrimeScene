"""Initialize only Prime Scene's own profile. No account import or app discovery."""
from pathlib import Path

import xbmcaddon
import xbmcvfs

ADDON_ID = 'plugin.video.primeinterface'


def prepare_profile():
    addon = xbmcaddon.Addon(ADDON_ID)
    profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    profile.mkdir(parents=True, exist_ok=True)
    marker = profile / 'profile-initialized'
    if marker.exists():
        return
    # Preserve an existing Prime Scene account/settings during updates.
    if not (profile / 'config/accounts.lst').exists():
        addon.setSetting('data_source', '0')
        addon.setSetting('playmethod', '3')
    marker.write_text('1', encoding='ascii')
