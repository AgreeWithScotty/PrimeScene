"""Use provider-declared cached imagery, with a bundled picture as a fallback."""
from os.path import join
from urllib.parse import unquote_plus, urlparse
import re
import unicodedata

# Local fallbacks are instant; never fan out category requests during startup.
CATEGORIES = (
    ('live-tv', r'\b(live tv|live television|live channels)\b'),
    ('news', r'\bnews\b'),
    ('my-stuff', r'\b(my stuff|watchlist|watch list|my library|purchases|rentals)\b'),
    ('home', r'\bhome\b'),
    ('family', r'\b(kids?|children|family)\b'),
    ('action', r'\b(action|adventure)\b'),
    ('mystery', r'\b(mystery|thriller|suspense|crime|detective)\b'),
    ('romance', r'\b(romance|romantic|love)\b'),
    ('horror', r'\b(horror|scary|terror)\b'),
    ('comedy', r'\b(comedy|comedies|funny|sitcom)\b'),
    ('sci-fi', r'\b(sci fi|science fiction|fantasy|space|superhero)\b'),
    ('documentary', r'\b(documentary|documentaries|nature|history|factual|biography)\b'),
    ('drama', r'\b(drama|dramatic)\b'),
    ('sports', r'\b(sports?|football|soccer|basketball|tennis)\b'),
    ('top-rated', r'\b(top rated|highest rated|award|critically acclaimed|best rated)\b'),
    ('new-releases', r'\b(new releases?|newly|recently added|just added|premiere|premium)\b'),
    ('popular', r'\b(popular|trending|most watched|top movies)\b'),
    ('tv', r'\b(tv|television|series|shows|episodes)\b'),
)


def fallback_name(title='', route=''):
    if route.startswith('pv/profiles/') or 'SwitchUser' in route:
        return 'category-profile.webp'
    if isinstance(title, bytes):
        title = title.decode('utf-8', 'replace')
    text = re.sub(r'\[/?[^\]]+\]', '', unquote_plus(title or ''))
    # Prefer the visible category name over ancestor names in its route.
    if not text.strip():
        text = unquote_plus(route.rsplit('/', 1)[-1])
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode().lower()
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    for slug, pattern in CATEGORIES:
        if re.search(pattern, text):
            return 'category-' + slug + '.webp'
    return 'category-cinema.webp'

IMAGE_FIELDS = ('thumb', 'poster', 'fanart', 'artmeta', 'image', 'images',
                'imageUrl', 'imageURL', 'thumbnailUrl', 'packshot', 'heroshot',
                'cover', 'backgroundImage')


def first_artwork(data, limit=200):
    """Bounded walk of cached metadata; never fetch or construct an image URL."""
    work = [(data, False)]
    count = 0
    while work and count < limit:
        value, image_context = work.pop()
        count += 1
        if isinstance(value, str) and image_context:
            parsed = urlparse(value)
            if parsed.scheme in ('http', 'https') and parsed.netloc and not parsed.path.lower().endswith(('.m3u8', '.mpd', '.mp4', '.ts')):
                return value
        elif isinstance(value, dict):
            preferred = [(value[key], True) for key in IMAGE_FIELDS if key in value]
            other = [(child, image_context) for key, child in value.items()
                     if key not in IMAGE_FIELDS and isinstance(child, (dict, list))]
            if image_context:
                preferred.extend((value[key], True) for key in ('url', 'src') if key in value)
            work.extend(reversed(preferred + other))
        elif isinstance(value, list):
            work.extend((child, image_context) for child in reversed(value[:40]))
    return None


def cached_node(provider, route):
    if not route.startswith('pv/browse/'):
        return None
    node = provider._catalog
    for part in route[len('pv/browse/'):].split('/'):
        key = unquote_plus(part)
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    return node


def apply_category_art(info, provider, route, plugin_path, title='', curated=False):
    if curated:
        # Home is an authored category collection, even if Amazon supplies art.
        image = join(plugin_path, 'resources', 'skins', 'Default', 'media', fallback_name(title, route))
        info.update(thumb=image, poster=image, fanart=image)
        return info
    if not info.get('thumb'):
        image = info.get('poster') or info.get('fanart')
        node = cached_node(provider, route)
        if not image and node is not None:
            image = first_artwork(node)
            if not image and isinstance(node, dict):
                for key in list(node)[:40]:
                    image = first_artwork(provider._videodata.get(key, {}))
                    if image:
                        break
        info['thumb'] = image or join(plugin_path, 'resources', 'skins', 'Default', 'media', fallback_name(title, route))
    return info
