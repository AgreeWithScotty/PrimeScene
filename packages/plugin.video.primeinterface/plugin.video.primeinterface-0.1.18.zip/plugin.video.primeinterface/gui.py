"""Separate script entry for the Prime Scene window."""
import sys
import xbmc
import xbmcgui

ID = 'plugin.video.primeinterface'


def main():
    # Provide the original backend with our native plugin URI for playback links.
    sys.argv[:] = ['plugin://' + ID + '/', '-1', '']
    from resources.lib.common import Globals, Settings
    from resources.lib.users import loadUser, loadUsers
    from resources.lib.dedicated_ui import open_interface
    from resources.lib.interface_diagnostics import record
    g, settings = Globals(), Settings()
    record(g, 'gui_script_started')
    users = loadUsers()
    if not users:
        xbmcgui.Dialog().ok('Prime Scene', 'Please reopen Prime Scene to sign in.')
        return

    def initialize_provider():
        g.InitialiseProvider(*(loadUser(key, cachedUsers=users) for key in
                               ('mid', 'baseurl', 'atvurl', 'pv', 'deviceid')))

    try:
        result = open_interface(g, settings, initialize_provider=initialize_provider)
        if result == 'classic':
            xbmc.executebuiltin('ActivateWindow(Videos,"plugin://' + ID + '/?mode=ClassicUI",return)')
    except Exception as error:
        record(g, 'window_open_failed', error)
        xbmcgui.Dialog().ok('Prime Scene', 'The interface could not open (' +
                           type(error).__name__ + '). Your sign-in is saved.')


if __name__ == '__main__':
    main()
