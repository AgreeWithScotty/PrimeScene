"""Single-worker bridge to the original Website provider. No stream resolution here."""
from copy import deepcopy
from urllib.parse import urlencode
from .category_art import apply_category_art


def is_title_card(info, playable=False):
    return playable or info.get('mediatype') in ('tvshow', 'season')


class DirectorySink:
    def __init__(self, original):
        self.original = original

    def __getattr__(self, name):
        return getattr(self.original, name)

    def addSortMethod(self, *args, **kwargs):
        pass

    def endOfDirectory(self, *args, **kwargs):
        pass


class ProviderBridge:
    def __init__(self, provider, globals_instance):
        from . import web_api
        self.module = web_api
        self.provider = provider
        self.g = globals_instance

    def browse(self, path, publish, query=None):
        """Used only by one background worker; restore all bindings on exit."""
        module, provider = self.module, self.provider
        saved = {key: getattr(module, key) for key in
                 ('addDir', 'addVideo', 'setContentAndView', 'xbmcplugin')}
        previous_progress = getattr(provider, '_stream_progress', None)
        capture = []

        def directory(name, mode='', url='', infoLabels=None, opt='', catalog='Browse',
                      cm=None, page=1, export=False, thumb=None):
            info = deepcopy(infoLabels or {})
            if thumb and not info.get('thumb'):
                info['thumb'] = thumb
            if not is_title_card(info):
                apply_category_art(info, provider, url, self.g.PLUGIN_PATH, name, curated=(path == 'root'))
            capture.append({'title': name, 'url': self.g.pluginid + url,
                            'video': False, 'info': info})

        def video(name, asin, infoLabels, cm=None, export=False):
            # Identical parameters to the upstream itemlisting.addVideo route.
            params = {'asin': asin, 'mode': 'PlayVideo', 'name': name,
                      'adult': infoLabels.get('isAdult', 0)}
            url = self.g.pluginid + '?' + urlencode(params)
            url += '&trailer={}&selbitrate=0'.format(
                {'live': 2, 'event': 3}.get(infoLabels['contentType'], 0))
            capture.append({'title': name, 'url': url, 'video': True,
                            'info': deepcopy(infoLabels)})

        def packet():
            prefix = self.g.pluginid + 'pv/browse/'
            rows, next_path = [], None
            for row in capture:
                if row['url'].startswith(prefix) and row['url'].endswith('/nextPage'):
                    next_path = row['url'][len(prefix):]
                else:
                    rows.append(row)
            return {'rows': deepcopy(rows), 'next': next_path}

        def progress(node, breadcrumb):
            # Reuse the original renderer against the partially populated node.
            # It supplies the same metadata and playback identifiers as Classic.
            old_traverse = provider._TraverseCatalog
            provider._TraverseCatalog = lambda *a, **k: (node, breadcrumb)
            capture.clear()
            try:
                provider.Browse('/'.join(breadcrumb))
                publish(packet())
            finally:
                provider._TraverseCatalog = old_traverse
                capture.clear()

        try:
            module.addDir, module.addVideo = directory, video
            module.setContentAndView = lambda *a, **kw: None
            module.xbmcplugin = DirectorySink(saved['xbmcplugin'])
            provider._stream_progress = progress
            if query is not None:
                provider.Search(query)
            elif path == 'root':
                provider.BrowseRoot()
            else:
                provider.Browse(path)
            result = packet()
            publish(result)
            return result
        finally:
            provider._stream_progress = previous_progress
            for key, value in saved.items():
                setattr(module, key, value)
