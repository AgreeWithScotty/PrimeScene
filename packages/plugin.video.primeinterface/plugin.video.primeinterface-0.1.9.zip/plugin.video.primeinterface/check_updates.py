"""Ask Kodi's repository manager to check; Kodi installs the update itself."""
import xbmc
import xbmcaddon
import xbmcgui


def main():
    try:
        xbmcaddon.Addon('repository.primescene')
    except RuntimeError:
        xbmcgui.Dialog().ok('Prime Scene updates',
                           'Install the Prime Scene Repository once. Then choose Install from repository > '
                           'Prime Scene Repository > Video add-ons > Prime Scene. '
                           'Use Versions on its information screen to select the repository release. '
                           'Your saved sign-in is kept.')
        return
    xbmc.executebuiltin('UpdateAddonRepos', True)
    xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/)')


if __name__=='__main__':
    main()
