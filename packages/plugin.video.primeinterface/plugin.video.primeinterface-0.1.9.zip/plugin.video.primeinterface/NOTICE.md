# Attribution and source

Prime Scene is an independent community fork, not an Amazon product.
The catalog, account and playback backend is derived from Sandmann79/xbmc,
Amazon VOD1.2.4+matrix.1, by Sandmann79, Varstahl and its other contributors:
https://github.com/Sandmann79/xbmc

Their GPL-3.0-or-later license and existing notices are retained. The complete
Python source and XML interface are included in this installable ZIP. Local
changes add a dedicated progressive interface, bounded category enrichment,
request/registration repairs, an isolated identity/profile/service namespace,
and its own first-launch sign-in flow. The original installed add-on's code is
never imported. Existing external Kodi Python modules remain dependencies.

Upstream dependency version attributes are compatibility minimums, not pins to
old dependency releases. Kodi resolves installed/current repository dependencies.
No old dependency package or Widevine binary is bundled.
