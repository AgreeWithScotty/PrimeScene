"""Single-worker bridge to the original Website provider. No stream resolution here."""
from copy import deepcopy
from os.path import join
from time import monotonic
from urllib.parse import urlencode, urljoin, urlsplit
from .category_art import apply_category_art, cached_node, first_artwork
from .public_catalog import ORIGIN, PublicCatalogError, detail_id, fetch_cards, safe_url


HOME_CAPACITY = 8
HOME_MORE = '__home_categories__'


def is_title_card(info, playable=False):
    return playable or info.get('mediatype') in ('tvshow', 'season', 'storefront')


class DirectorySink:
    def __init__(self, original):
        self.original = original

    def __getattr__(self, name):
        return getattr(self.original, name)

    def addSortMethod(self, *args, **kwargs):
        pass

    def endOfDirectory(self, *args, **kwargs):
        pass


class ProviderBridge:
    def __init__(self, provider, globals_instance):
        from . import web_api
        self.module = web_api
        self.provider = provider
        self.g = globals_instance
        self.public_pages = {}
        self.provider._prime_scene_details = {}

    def storefront_page(self, path):
        # The public reader has only been verified on this storefront.
        if getattr(self.g, 'BaseUrl', '').rstrip('/') != ORIGIN:
            return None
        if path.count('/') != 1 or not path.startswith('root/'):
            return None
        node = cached_node(self.provider, 'pv/browse/' + path) or {}
        url = node.get('ref') or node.get('lazyLoadURL') or ''
        slug = urlsplit(url).path.rstrip('/').rsplit('/', 1)[-1].lower()
        if slug in ('storefront', 'home'):
            return 'home'
        if slug in ('movie', 'movies'):
            return 'movies'
        if slug == 'tv':
            return 'tv'
        return {'home': 'home', 'movies': 'movies', 'tv shows': 'tv',
                'tv': 'tv'}.get(node.get('title', '').strip().casefold())

    def public_packet(self, page, active):
        cached = self.public_pages.get(page)
        if cached and monotonic() - cached[0] < 120:
            cards = cached[1]
        else:
            try:
                cards = fetch_cards(page)
            except (OSError, PublicCatalogError, ValueError):
                return None
            self.public_pages[page] = (monotonic(), cards)
        if not active():
            return None
        rows = []
        for card in cards:
            url = safe_url(card.detail_url, 'www.primevideo.com')
            key = detail_id(url)
            if not key:
                continue
            self.provider._prime_scene_details.setdefault(
                key, {'title': card.title, 'lazyLoadURL': url})
            rows.append({'title': card.title,
                         'url': self.g.pluginid + 'pv/browse/__storefront__/' + key,
                         'video': False, 'identity': key,
                         'info': {'poster': card.artwork_url, 'mediatype': 'storefront'}})
        return {'rows': rows, 'next': None, 'mixed_grid': True} if rows else None

    def browse_progressive(self, path, publish, active, query=None):
        if path in ('root', HOME_MORE):
            # The landing screen is a fixed category dashboard. Storefront
            # titles are available from the Home tile and the Movies/TV tiles.
            packet = self.browse('root', lambda packet: None, incremental=False, whole_page=True)
            rows = [row for row in packet['rows'] if '?mode=Search' not in row['url']]
            if path == HOME_MORE:
                publish({'rows': rows[HOME_CAPACITY - 1:], 'next': packet['next']})
            elif len(rows) > HOME_CAPACITY or packet['next']:
                image = join(self.g.PLUGIN_PATH, 'resources', 'skins', 'Default', 'media',
                             'category-cinema.webp')
                more = {'title': 'More categories', 'url': self.g.pluginid + 'pv/browse/' + HOME_MORE,
                        'video': False, 'info': {'thumb': image}}
                if len(rows) >= HOME_CAPACITY:
                    publish({'rows': rows[:HOME_CAPACITY - 1] + [more], 'next': None})
                else:
                    publish({'rows': rows + [more], 'next': None})
            else:
                publish({'rows': rows, 'next': None})
            return
        page = self.storefront_page(path) if query is None else None
        if not active():
            return
        packet = self.browse(path, publish, query=query, incremental=False, whole_page=True)
        if page and not packet['rows'] and not packet['next'] and active():
            packet = self.public_packet(page, active)
            if packet:
                publish(packet)

    def browse(self, path, publish, query=None, incremental=True, whole_page=False):
        """Used only by one background worker; restore all bindings on exit."""
        module, provider = self.module, self.provider
        saved = {key: getattr(module, key) for key in
                 ('addDir', 'addVideo', 'setContentAndView', 'xbmcplugin')}
        previous_progress = getattr(provider, '_stream_progress', None)
        previous_listing = getattr(provider, '_prime_scene_listing_card', None)
        capture = []

        def identity(entry):
            if not entry:
                return None
            url = entry.get('ref') or entry.get('lazyLoadURL') or ''
            return detail_id(url) or entry.get('metadata', {}).get('compactGTI')

        def listing_card(node, item, url, title=None, artwork=None):
            base = getattr(self.g, 'BaseUrl', '')
            if not isinstance(url, str) or not url or not base:
                return
            try:
                url = urljoin(base, url)
                parsed = urlsplit(url)
                if parsed.scheme != 'https' or parsed.netloc != urlsplit(base).netloc:
                    return
            except ValueError:
                return
            label = title or item.get('title') or item.get('heading') or item.get('displayTitle')
            if isinstance(label, dict):
                label = label.get('text') or label.get('title')
            if not isinstance(label, str) or not label.strip():
                return
            match = provider._reURN.search(parsed.path) if not title else None
            cover = artwork if isinstance(artwork, str) and artwork.startswith('https://') else first_artwork(item)
            key = 'listed_' + (match.group(1) if match else str(len(node)))
            node.setdefault(key, {'title': label, 'lazyLoadURL': url, 'metadata': {
                'prime_scene_card': bool(match), 'artmeta': {'thumb': cover} if cover else {}}})

        def directory(name, mode='', url='', infoLabels=None, opt='', catalog='Browse',
                      cm=None, page=1, export=False, thumb=None):
            info = deepcopy(infoLabels or {})
            node = cached_node(provider, url)
            if node and node.get('metadata', {}).get('prime_scene_card'):
                info['mediatype'] = 'storefront'
            if thumb and not info.get('thumb'):
                info['thumb'] = thumb
            if not is_title_card(info):
                apply_category_art(info, provider, url, self.g.PLUGIN_PATH, name, curated=(path == 'root'))
            capture.append({'title': name, 'url': self.g.pluginid + url,
                            'video': False, 'info': info,
                            'identity': identity(node) if is_title_card(info) else None})

        def video(name, asin, infoLabels, cm=None, export=False):
            # Identical parameters to the upstream itemlisting.addVideo route.
            params = {'asin': asin, 'mode': 'PlayVideo', 'name': name,
                      'adult': infoLabels.get('isAdult', 0)}
            url = self.g.pluginid + '?' + urlencode(params)
            url += '&trailer={}&selbitrate=0'.format(
                {'live': 2, 'event': 3}.get(infoLabels['contentType'], 0))
            capture.append({'title': name, 'url': url, 'video': True,
                            'info': deepcopy(infoLabels),
                            'identity': identity(provider._videodata.get(asin))})

        def packet():
            prefix = self.g.pluginid + 'pv/browse/'
            rows, next_path = [], None
            for row in capture:
                if row['url'].startswith(prefix) and row['url'].endswith('/nextPage'):
                    next_path = row['url'][len(prefix):]
                else:
                    rows.append(row)
            return {'rows': deepcopy(rows), 'next': next_path}

        def progress(node, breadcrumb):
            if not incremental:
                # Publish a continuation in one grid update. The provider
                # still suppresses its own page-loading notifications.
                return
            # Reuse the original renderer against the partially populated node.
            # It supplies the same metadata and playback identifiers as Classic.
            old_traverse = provider._TraverseCatalog
            provider._TraverseCatalog = lambda *a, **k: (node, breadcrumb)
            capture.clear()
            try:
                provider.Browse('/'.join(breadcrumb))
                publish(packet())
            finally:
                provider._TraverseCatalog = old_traverse
                capture.clear()

        try:
            module.addDir, module.addVideo = directory, video
            module.setContentAndView = lambda *a, **kw: None
            module.xbmcplugin = DirectorySink(saved['xbmcplugin'])
            provider._stream_progress = progress
            provider._prime_scene_listing_card = listing_card if whole_page else None
            if query is not None:
                provider.Search(query)
            elif path == 'root':
                provider.BrowseRoot()
            else:
                provider.Browse(path)
            result = packet()
            publish(result)
            return result
        finally:
            provider._stream_progress = previous_progress
            provider._prime_scene_listing_card = previous_listing
            for key, value in saved.items():
                setattr(module, key, value)
