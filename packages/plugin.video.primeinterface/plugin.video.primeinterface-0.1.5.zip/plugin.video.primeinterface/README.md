# Prime Scene

Standalone Kodi video add-on, permanent ID `plugin.video.primeinterface`.
Current release:0.1.5. Display name: Prime Scene. It contains its own copy of the catalog, authentication,
playback/proxy backend and the dedicated progressive interface. Amazon VOD is
not a dependency and no installed Amazon VOD source file is imported or patched.

## Install

In Kodi choose **Add-ons â†’ Install from ZIP file**, then select
`plugin.video.primeinterface-0.1.5.zip`. It appears under Video add-ons as
**Prime Scene**, with a cyan PS icon. No PowerShell installer is used.
Keep the existing Kodi Python dependencies and Widevine available; these are
shared Kodi components, not code loaded from the old Amazon VOD add-on.

On first launch, Prime Scene prompts you to sign in to Amazon Prime Video using
its own login flow. Cancel closes the add-on; opening it again offers sign-in
until an account is saved. A successful sign-in opens the dedicated interface.
Future launches and normal updates retain that account. It never checks for the
old add-on or offers account import. Its own settings, cache and background proxy
are separate. Default source is Website; default playback is Kodi InputStream.
Phone/code authorization remains future work.

If the earlier PowerShell interface preview was installed into Amazon VOD,
its own `Apply-AmazonInterface.ps1 -Restore` can restore that old add-on. This
standalone package does not require the preview, its patches, or Amazon VOD.
You may keep both add-ons installed while testing. Removing Amazon VOD afterward
does not affect Prime Scene's own source or account/profile.

## Updates

Future releases keep **the same ID** and increment the version, for example
0.1.0 â†’0.1.1. Install the newer ZIP through Kodi's **Install from ZIP file**;
Kodi treats it as an update to Prime Scene. Do not uninstall between versions.
The profile `userdata/addon_data/plugin.video.primeinterface/` is kept separately
from the add-on program folder, so normal updates preserve settings and sign-in.
Install the Prime Scene Repository once to enable Kodi updates. Settings -> Updates -> Check for updates refreshes repositories and opens Kodi's update manager.

## Current interface and limits

Native Kodi card grid and sidebar, progressive title updates, automatic next-batch
loading near the end, Search, and a Classic view using this add-on's OWN backend.
Classic supplies profile/account tools, export and watchlist context menus.
Website source is supported by the new screen; Android uses this add-on's Classic
view. In-flight requests finish under the existing timeout when leaving a page.

Local tests verify package structure, identity isolation, first-launch sign-in and cancellation, update/profile retention, progressive provider results and
original playback routing. Actual installation/rendering and playback under the
new identity still need testing on the Kodi computer. This is a preview release.

Source/build/tests are under `Amazon/Prime Interface/` in this project. The ZIP
contains the full runnable Python/XML source and GPL license. See NOTICE.md for
the original backend authors and current compatibility minimums.

## Loading-wheel startup correction in0.1.3

The plugin request now completes before a separate `gui.py` script opens the
native window. The window follows Kodi's native constructor lifecycle without
calling its base initializer with XML arguments again. The provider/cache load
runs on the catalog worker after the shell is initialized. An unnecessary
post-launch settings-monitor wait was removed from the plugin entrypoint.

If0.1.2 is stuck, restart Kodi, install0.1.3 as an update, and reopen Prime Scene.
Do not uninstall or clear account data. Your saved sign-in should be reused.
If it still fails, send `interface-startup.jsonl` from your own Prime Scene
userdata folder (Windows: `%APPDATA%\Kodi\userdata\addon_data\plugin.video.primeinterface`).
This trace contains startup stage names and exception types, not account values
or request URLs. It is written without needing verbose logging.

Local strict-native-base and startup-order tests pass; the actual Kodi renderer
and this updated launch handoff still require remote testing.
