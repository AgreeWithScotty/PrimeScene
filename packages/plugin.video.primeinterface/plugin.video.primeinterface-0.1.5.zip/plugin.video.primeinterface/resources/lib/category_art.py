"""Use provider-declared cached imagery, with a bundled picture as a fallback."""
from os.path import join
from urllib.parse import unquote_plus, urlparse

IMAGE_FIELDS = ('thumb', 'poster', 'fanart', 'artmeta', 'image', 'images',
                'imageUrl', 'imageURL', 'thumbnailUrl', 'packshot', 'heroshot',
                'cover', 'backgroundImage')


def first_artwork(data, limit=200):
    """Bounded walk of cached metadata; never fetch or construct an image URL."""
    work = [(data, False)]
    count = 0
    while work and count < limit:
        value, image_context = work.pop()
        count += 1
        if isinstance(value, str) and image_context:
            parsed = urlparse(value)
            if parsed.scheme in ('http', 'https') and parsed.netloc and not parsed.path.lower().endswith(('.m3u8', '.mpd', '.mp4', '.ts')):
                return value
        elif isinstance(value, dict):
            preferred = [(value[key], True) for key in IMAGE_FIELDS if key in value]
            other = [(child, image_context) for key, child in value.items()
                     if key not in IMAGE_FIELDS and isinstance(child, (dict, list))]
            if image_context:
                preferred.extend((value[key], True) for key in ('url', 'src') if key in value)
            work.extend(reversed(preferred + other))
        elif isinstance(value, list):
            work.extend((child, image_context) for child in reversed(value[:40]))
    return None


def cached_node(provider, route):
    if not route.startswith('pv/browse/'):
        return None
    node = provider._catalog
    for part in route[len('pv/browse/'):].split('/'):
        key = unquote_plus(part)
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    return node


def apply_category_art(info, provider, route, plugin_path):
    if not info.get('thumb'):
        image = info.get('poster') or info.get('fanart')
        node = cached_node(provider, route)
        if not image and node is not None:
            image = first_artwork(node)
            if not image and isinstance(node, dict):
                for key in list(node)[:40]:
                    image = first_artwork(provider._videodata.get(key, {}))
                    if image:
                        break
        info['thumb'] = image or join(plugin_path, 'resources', 'skins', 'Default', 'media', 'category-cinema.png')
    return info
