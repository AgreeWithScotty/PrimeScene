# Bundled category picture

Final workspace asset: `Amazon/Prime Interface/src/assets/category-cinema.png`.
Packaged path: `resources/skins/Default/media/category-cinema.png`.
Generated with the built-in image-generation tool, then copied into the project
without editing. No third-party image URL is needed for this fallback.
The provider's declared cached artwork is preferred when present.

Final prompt:

> Use case: stylized-concept. Asset type: a real background picture for a category
> card in a premium television streaming interface, not a UI mockup. Create one
> wide 16:9 landscape cinematic still life: a beautiful vintage film projector and
> a curled film reel, softly illuminated by a warm gold projector beam, deep
> midnight navy studio with subtle cyan bokeh and elegant subdued film atmosphere.
> Main objects large and readable at small thumbnail size. Keep the bottom fifth
> dark and uncluttered for a separate interface caption. Restrained, polished
> photographic concept art. No people, no logos, no words or letters, no watermark,
> no frame. This single asset is used as a fallback category illustration when
> the content provider supplies no artwork. Aim for a compact 1024 by 576 image.
