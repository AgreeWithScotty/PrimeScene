# Smooth Prime

A dedicated Prime Video interface for Kodi, maintained by AgreeWithScotty.

In Progress is fetched fresh from Amazon on every visit and playback return.
Movies and TV show Prime-included titles; Sports and Purchases have separate
selectors. Catalog pages, artwork and descriptions preload independently.
Shows open their episodes and seasons; movies play their selected title.
Keyboard/remote focus starts on In Progress. Playback returns to its card.

Native account prompts handle Amazon verification without opening a browser.
Sign-out invalidates the session and purges account data before another login.
The catalog, HTTPS transport and media playback backend are independent native
implementations with no former provider fallback or runtime import.

Playback uses Kodi InputStream Adaptive/Widevine. It requests the actual selected
provider media resource and relays CDM license requests without changing sources,
decrypting content or extracting keys. Native Kodi controls remain. Local resume
storage is separate from Amazon's fresh In Progress list.

Settings contains account, playback, updates and complete diagnostics. Reports
capture release/environment, operation/attempt/request IDs, stages/timings,
redacted HTTP redirects/status, parser/protocol and provider error codes,
native player/window state, cancellation/failure and logging errors. Passwords,
verification codes, tokens, cookies and private account identities are excluded.

Same permanent add-on ID: plugin.video.primeinterface. Installations update in
place. See NOTICE.md and LICENSE for current source and asset licensing.


0.2.24 browsing: shows open season cards first, then the selected season episodes. Focusing a top content tab loads its section. Press Down on Movies or TV for genres, Enter to select, or Back to close the drawer. The far-right signed-in account action says Sign out. Focus glow follows the active skin font across the entire word.
