# Prime Scene for Prime Video

Standalone Kodi video add-on, permanent ID `plugin.video.primeinterface`.
Current release:0.1.19. Includes its own catalog, authentication, playback/proxy
backend and dedicated progressive interface. No installed Amazon VOD add-on is
required, queried or imported.

## Install and update

Install the Prime Scene Repository once, then choose **Install from repository ->
Prime Scene Repository -> Video add-ons -> Prime Scene**. On the add-on information screen, use the bottom **Versions** button to select
the Prime Scene Repository release once. Later available updates use Kodi's
bottom **Update** button. A manually installed ZIP may still show Origin: Manual
until the repository version is selected. The optional settings update shortcut
refreshes repositories and opens Kodi's available updates. Close and reopen Prime Scene after
updating. The gold projector icon is labeled **Prime Scene / for Prime Video**.
Kodi InputStream and Widevine are shared playback components.

Releases keep the same add-on ID. Kodi updates preserve the separate profile
`userdata/addon_data/plugin.video.primeinterface/`, including saved sign-in.
Hosted repository: https://github.com/AgreeWithScotty/PrimeScene.
Kodi automatic updates are also supported. Do not uninstall between updates.

## Sign-in

First launch prompts for its own Amazon Prime Video sign-in, with cancellation.
Future launches reuse its saved account. No account import from another add-on.
Default source is Website; default playback is Kodi InputStream.
Phone/code authorization remains future work.

## New in 0.1.7

Fixed the blank Updates settings category and missing action using numeric
language IDs. Kodi owns the normal bottom-row Versions/Update controls.

## Artwork introduced in 0.1.6

Rounded, framed inset sidebar buttons retain black backgrounds, gold lettering
and blue focus. Genre/section-specific cinematic pictures appear immediately. Home always uses
our artwork and places categories at the top without library/profile headings.
Other pages prefer available Amazon imagery with local fallbacks. No category
preload requests are added. New versioned icon and backdrop identify Prime Video.
Artwork fit and selected-card preservation during progressive appends remain.

## Interface and verification

Native card grid, progressive results, automatic next-batch loading and Search.
The sidebar uses the Prime Scene icon and three black-and-gold buttons. Escape and Back return to the preceding catalog page. From the main page they
close Prime Scene and return directly to Kodi Home. The next batch loads in the
background when the cursor is within two rows of the end. In-flight
requests finish under the existing timeout when leaving a page.

The user confirmed that the dedicated UI opens on Kodi. This release's actual
screen appearance still needs checking on that computer. Local tests cover
artwork selection, native-style focus resets, first sign-in/cancellation,
startup order, package isolation, update/profile retention and playback routes.
Playback code remains identical to the published upstream baseline.

If startup fails, inspect `interface-startup.jsonl` in this add-on's own profile.
It contains stage names and exception types, without account values or URLs.

The ZIP includes full runnable Python/XML source and GPL license. See NOTICE.md
for backend credits and dependency minimums. Source/build/tests are under
`Amazon/Prime Interface/` in this project. Not affiliated with Amazon.
