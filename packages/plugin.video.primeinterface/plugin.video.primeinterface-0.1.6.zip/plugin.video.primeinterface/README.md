# Prime Scene for Prime Video

Standalone Kodi video add-on, permanent ID `plugin.video.primeinterface`.
Current release:0.1.6. Includes its own catalog, authentication, playback/proxy
backend and dedicated progressive interface. No installed Amazon VOD add-on is
required, queried or imported.

## Install and update

Install the Prime Scene Repository once, then choose **Install from repository ->
Prime Scene Repository -> Video add-ons -> Prime Scene**. Existing users can use
**Settings -> Updates -> Check for updates**. Close and reopen Prime Scene after
updating. The gold projector icon is labeled **Prime Scene / for Prime Video**.
Kodi InputStream and Widevine are shared playback components.

Releases keep the same add-on ID. Kodi updates preserve the separate profile
`userdata/addon_data/plugin.video.primeinterface/`, including saved sign-in.
Hosted repository: https://github.com/AgreeWithScotty/PrimeScene.
Kodi automatic updates are also supported. Do not uninstall between updates.

## Sign-in

First launch prompts for its own Amazon Prime Video sign-in, with cancellation.
Future launches reuse its saved account. No account import from another add-on.
Default source is Website; default playback is Kodi InputStream.
Phone/code authorization remains future work.

## New in 0.1.6

Rounded, framed inset sidebar buttons retain black backgrounds, gold lettering
and blue focus. Genre/section-specific cinematic pictures appear immediately. Home always uses
our artwork and places categories at the top without library/profile headings.
Other pages prefer available Amazon imagery with local fallbacks. No category
preload requests are added. New versioned icon and backdrop identify Prime Video.
Artwork fit and selected-card preservation during progressive appends remain.

## Interface and verification

Native card grid, progressive results, automatic next-batch loading, Search and
Classic view backed by this add-on's own code. Classic supplies profile/account
tools, export and watchlist context menus. Android uses Classic view. In-flight
requests finish under the existing timeout when leaving a page.

The user confirmed that the dedicated UI opens on Kodi. This release's actual
screen appearance still needs checking on that computer. Local tests cover
artwork selection, native-style focus resets, first sign-in/cancellation,
startup order, package isolation, update/profile retention and playback routes.
Playback code remains identical to the published upstream baseline.

If startup fails, inspect `interface-startup.jsonl` in this add-on's own profile.
It contains stage names and exception types, without account values or URLs.

The ZIP includes full runnable Python/XML source and GPL license. See NOTICE.md
for backend credits and dependency minimums. Source/build/tests are under
`Amazon/Prime Interface/` in this project. Not affiliated with Amazon.
