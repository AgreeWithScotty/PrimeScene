"""Native Kodi streaming interface. One provider worker, generation-scoped updates."""
from queue import Empty, Queue
from threading import Event, RLock, Thread
import xbmc
import xbmcgui

from .dedicated_bridge import ProviderBridge
from .interface_diagnostics import record


class StreamingWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.g = kwargs.pop('globals_instance')
        self.initialize_provider = kwargs.pop('initialize_provider', None)
        # Kodi constructs WindowXML in __new__; do not call object.__init__ with
        # XML filename/path arguments a second time.
        self.init_error = None
        self.jobs = Queue()
        self.stop = Event()
        self.lock = RLock()
        self.generation = 0
        self.rows = []
        self.items = []
        self.lookup = {}
        self.history = []
        self.path = 'root'
        self.next_path = None
        self.busy = False
        self.result = None
        self.worker = None

    def onInit(self):
        if self.worker is not None:
            return
        record(self.g, 'window_initialized')
        try:
            self._initialize_controls()
        except Exception as error:
            self.init_error = type(error).__name__
            record(self.g, 'window_init_failed', error)
            self.stop.set()
            self.close()

    def _initialize_controls(self):
        self.setProperty('heading', 'Your Prime Video library')
        self.setProperty('status', 'Connecting to Amazonâ€¦')
        self.worker = Thread(target=self._work, name='PrimeCatalog', daemon=True)
        self.navigate('root', remember=False)
        self.setFocusId(200)
        self.worker.start()

    def navigate(self, path, remember=True, query=None, selection=0):
        with self.lock:
            if remember:
                self.history.append((self.path, self.getControl(200).getSelectedPosition()))
            self.path = path
            self.setProperty('rootview', 'true' if path == 'root' else 'false')
            self.generation += 1
            self.rows, self.items, self.lookup = [], [], {}
            self.getControl(200).reset()
            self.clearProperty('hascontent')
            self.setProperty('status', 'Connecting to Amazonâ€¦')
            self.next_path = None
            self.busy = True
            self.jobs.put((self.generation, path, query, selection))

    def _publish(self, token, packet):
        with self.lock:
            if self.stop.is_set() or token != self.generation:
                return
            control = self.getControl(200)
            additions = []
            for row in packet['rows']:
                key = row['url']
                if key in self.lookup:
                    continue
                item = xbmcgui.ListItem(label=row['title'])
                info = row['info']
                if not info.get('thumb'):
                    from os.path import join
                    info['thumb'] = info.get('poster') or info.get('fanart') or join(
                        self.g.PLUGIN_PATH, 'resources', 'skins', 'Default', 'media', 'category-cinema.webp')
                item.setArt({k: info[k] for k in ('thumb', 'poster', 'fanart') if info.get(k)})
                item.setProperty('summary', str(info.get('plot', '')))
                item.setProperty('year', str(info.get('year') or ''))
                item.setProperty('action', 'Watch' if row['video'] else 'Explore')
                self.lookup[key] = len(self.rows)
                self.rows.append(row)
                self.items.append(item)
                additions.append(item)
            if additions:
                # Some native containers reset selection when their contents grow.
                # Capture the selected existing route just before the mutation,
                # append once, then restore that same card without changing focus.
                selected = control.getSelectedPosition()
                existing_count = len(self.rows) - len(additions)
                selected_key = (self.rows[selected]['url']
                                if 0 <= selected < existing_count else None)
                control.addItems(additions)
                if selected_key is not None:
                    control.selectItem(self.lookup[selected_key])
            self.next_path = packet['next']
            if self.rows:
                self.setProperty('hascontent', 'true')
                self.setProperty('status', '')

    def _work(self):
        try:
            record(self.g, 'provider_initializing')
            if self.initialize_provider is not None:
                self.initialize_provider()
            bridge = ProviderBridge(self.g.pv, self.g)
            record(self.g, 'provider_ready')
        except Exception as error:
            record(self.g, 'provider_init_failed', error)
            if not self.stop.is_set():
                self.setProperty('status', 'Could not open the catalog. Your sign-in is saved; use Classic view or reopen to retry.')
            self.busy = False
            return
        monitor = xbmc.Monitor()
        while not self.stop.is_set() and not monitor.abortRequested():
            try:
                token, path, query, selection = self.jobs.get(timeout=0.15)
            except Empty:
                self._prefetch()
                continue
            if token != self.generation:
                continue
            try:
                record(self.g, 'catalog_request_started')
                bridge.browse(path, lambda packet: self._publish(token, packet), query=query)
                record(self.g, 'catalog_request_finished')
                with self.lock:
                    if token == self.generation and not self.stop.is_set():
                        if not self.rows:
                            self.setProperty('status', 'No titles were returned. Try Home or Classic view.')
                        if selection:
                            self.getControl(200).selectItem(min(selection, max(0, len(self.rows)-1)))
            except BaseException as error:
                record(self.g, 'catalog_request_failed', error)
                # No request URLs, tokens or exception bodies enter this log.
                xbmc.log('[Prime Scene] Catalog operation failed: ' + type(error).__name__, xbmc.LOGERROR)
                with self.lock:
                    if token == self.generation and not self.stop.is_set():
                        self.setProperty('status', 'Unable to finish loading. Return Home to retry, or use Classic view.')
            finally:
                with self.lock:
                    if token == self.generation:
                        self.busy = False

    def _prefetch(self):
        with self.lock:
            if self.busy or not self.next_path or not self.rows or self.stop.is_set():
                return
            if self.getFocusId() != 200:
                return
            selected = self.getControl(200).getSelectedPosition()
            if selected >= max(0, len(self.rows) - 3):
                path = self.next_path
                self.next_path = None
                self.busy = True
                self.jobs.put((self.generation, path, None, 0))

    def onClick(self, controlId):
        if controlId == 101:
            self.setProperty('heading', 'Your Prime Video library')
            self.navigate('root', remember=False)
            self.history = []
        elif controlId == 102:
            phrase = self.g.dialog.input('Search Prime Video').strip()
            if phrase:
                self.setProperty('heading', 'Search results')
                self.navigate('search', query=phrase)
        elif controlId == 103:
            self.g.addon.openSettings()
        elif controlId == 104:
            self.result = 'classic'
            self.stop.set()
            self.close()
        elif controlId == 200:
            with self.lock:
                index = self.getControl(200).getSelectedPosition()
                if not 0 <= index < len(self.rows):
                    return
                row = dict(self.rows[index])
            if row['video']:
                xbmc.Player().play(row['url'])
            elif row['url'].startswith(self.g.pluginid + 'pv/browse/'):
                self.setProperty('heading', row['title'])
                self.navigate(row['url'].split('pv/browse/', 1)[1])
            elif '?mode=Search' in row['url']:
                self.onClick(102)
            else:
                self.g.dialog.ok('Prime Video', 'Use Classic view for account/profile tools and this menu item.')

    def onAction(self, action):
        if action.getId() not in (9, 10, 92):
            return
        if self.history:
            path, selected = self.history.pop()
            self.navigate(path, remember=False, selection=selected)
            self.setProperty('heading', 'Your Prime Video library')
        else:
            self.stop.set()
            self.close()


def open_interface(globals_instance, settings_instance, initialize_provider=None):
    if settings_instance.data_source != 0:
        globals_instance.dialog.ok('Prime Video', 'This preview currently supports the Website data source. Opening Classic view.')
        return 'classic'
    record(globals_instance, 'window_creating')
    window = StreamingWindow('PrimeStreaming.xml', globals_instance.PLUGIN_PATH,
                             'Default', '1080i', globals_instance=globals_instance,
                             initialize_provider=initialize_provider)
    try:
        window.doModal()
    finally:
        window.stop.set()
        # Finish the current bounded batch before restoring provider bindings.
        # In-flight HTTP calls retain their existing timeout; no thread is killed.
        if window.worker is not None:
            while window.worker.is_alive():
                window.worker.join(0.1)
    if window.init_error is not None:
        globals_instance.dialog.ok('Prime Scene', 'The interface could not initialize (' +
                                   window.init_error + '). Your sign-in is saved.')
    return window.result
